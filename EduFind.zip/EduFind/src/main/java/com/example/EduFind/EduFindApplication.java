package com.example.EduFind;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EduFindApplication {

	public static void main(String[] args) {
		SpringApplication.run(EduFindApplication.class, args);
	}

}
