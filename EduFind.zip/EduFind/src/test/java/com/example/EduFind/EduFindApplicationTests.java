package com.example.EduFind;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EduFindApplicationTests {

	@Test
	void contextLoads() {
	}

}
